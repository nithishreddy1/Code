package com.comcast.config;

import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProvider;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProviderClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder.defaultClient;


@Configuration
public class AwsConfig {

    @Bean
    public AWSSecretsManager secretsManager(){return AWSSecretsManagerClientBuilder.defaultClient();}

    @Bean
    public AmazonS3 s3Client(){return AmazonS3ClientBuilder.defaultClient(); }

    @Bean
    public AWSCognitoIdentityProvider cognitoClient(){return AWSCognitoIdentityProviderClientBuilder.defaultClient();
    }
}
