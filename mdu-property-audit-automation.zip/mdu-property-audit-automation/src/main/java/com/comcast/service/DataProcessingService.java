package com.comcast.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

@Service
public class DataProcessingService {
    private static final Logger LOG = LoggerFactory.getLogger(DataProcessingService.class);

    @Autowired
    private SecretService secretService;

    @Autowired
    private HttpService httpService;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final ExecutorService executor = Executors.newFixedThreadPool(10);
    
    public CompletableFuture<List<Map<String, Object>>> processUnitsAsync(
            List<Map<String, Object>> unitsList, String elocToken, String ftnsToken, Map<String, Object> secret) {
        
        List<CompletableFuture<Map<String, Object>>> futures = unitsList.stream()
            .map(unit -> processUnitAsync(unit, elocToken, ftnsToken, secret))
            .collect(Collectors.toList());
            
        return CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
            .thenApply(v -> futures.stream()
                .map(CompletableFuture::join)
                .collect(Collectors.toList()));
    }
    
    private CompletableFuture<Map<String, Object>> processUnitAsync(
            Map<String, Object> unit, String elocToken, String ftnsToken, Map<String, Object> secret) {
        
        return CompletableFuture.supplyAsync(() -> {
            String locationId = (String) unit.get("location_id");
            LOG.info("Processing for location id: {}", locationId);
            
            // Fetch ELOC data
            Map<String, Object> elocData = fetchElocData(locationId, elocToken, secret);
            
            // Fetch FTNS data
            Map<String, Object> ftnsData = fetchFtnsData(locationId, ftnsToken, secret);
            
            return processUnitData(unit, elocData, ftnsData);
        }, executor);
    }
    
    @SuppressWarnings("unchecked")
    private Map<String, Object> processUnitData(Map<String, Object> unit, Map<String, Object> elocData, Map<String, Object> ftnsData) {
        Map<String, Object> result = new HashMap<>();
        
        String unitName = (String) unit.get("name");
        String locationId = (String) unit.get("location_id");
        String unitHouseKey = (String) unit.get("house_key");
        String unitTypeInXc2 = (String) unit.get("type");
        
        List<Map<String, Object>> addressList = (List<Map<String, Object>>) unit.get("address");
        String streetAddress = addressList != null && !addressList.isEmpty() ? 
            (String) addressList.get(0).get("street_address") : "NA";
        
        String cbFlagEnableInXc2 = "CB".equals(unitTypeInXc2) ? "Yes" : "No";
        
        // Process resident details
        List<Map<String, Object>> residents = (List<Map<String, Object>>) unit.get("residents");
        Map<String, Object> residentDetails = processResidentList(residents);
        
        String xc2ResidentName = "";
        String billingAccountInXc2 = "";
        
        if (residentDetails != null) {
            String firstName = Optional.ofNullable((String) residentDetails.get("first_name")).orElse("").trim();
            String lastName = Optional.ofNullable((String) residentDetails.get("last_name")).orElse("").trim();
            xc2ResidentName = (firstName + " " + lastName).trim();
            billingAccountInXc2 = Optional.ofNullable((String) residentDetails.get("csg_billing_id")).orElse("");
        }
        
        // Process ELOC data
        String dropCell = "NA";
        if (elocData != null) {
            Map<String, Object> billingDetailsInfo = (Map<String, Object>) elocData.get("billingDetailsInfo");
            if (billingDetailsInfo != null) {
                List<Map<String, Object>> csgDetails = (List<Map<String, Object>>) billingDetailsInfo.get("csgDetails");
                if (csgDetails != null && !csgDetails.isEmpty()) {
                    dropCell = Optional.ofNullable((String) csgDetails.get(0).get("cell")).orElse("NA");
                }
            }
        }
        
        // Process FTNS data
        String[] ftnsResult = processFtnsData(ftnsData);
        String accountNumberInFtns = ftnsResult[0];
        String statusInFtns = ftnsResult[1];
        String nameInFtns = ftnsResult[2];
        String mac = ftnsResult[3];
        
        // Calculate matches
        String nameMatch = xc2ResidentName.toLowerCase().equals(nameInFtns.toLowerCase()) && 
            !xc2ResidentName.isEmpty() && !nameInFtns.isEmpty() ? "Yes" : "No";
        
        String masa = accountNumberInFtns.contains("/") ? "Yes" : "No";
        String cpgFlag = "CPG".equals(dropCell) ? "Yes" : "No";
        String accountMatch = billingAccountInXc2.equals(accountNumberInFtns) && 
            !billingAccountInXc2.isEmpty() && "No".equals(masa) ? "Yes" : "No";
        

        result.put("Unit Name", unitName);
        result.put("House Key", unitHouseKey);
        result.put("Location ID", locationId);
        result.put("Address Line 1", streetAddress);
        result.put("Drop Cell", dropCell);
        result.put("MASA", masa);
        result.put("CxB Badge on Servicability Page", cpgFlag);
        result.put("XC2 Enabled", cbFlagEnableInXc2);
        result.put("XC2 Resident Name", xc2ResidentName.toLowerCase());
        result.put("E360 Customer Name", nameInFtns.toLowerCase());
        result.put("Name Match?", nameMatch);
        result.put("E360 Account Number", accountNumberInFtns);
        result.put("XC2 Account Number", billingAccountInXc2);
        result.put("Match?", accountMatch);
        result.put("OnRamp Device", mac);
        
        return result;
    }
    
    @SuppressWarnings("unchecked")
    private Map<String, Object> processResidentList(List<Map<String, Object>> residentList) {
        if (residentList == null) return null;
        
        // Priority 1: primary_billing_account and csg_billing_id
        for (Map<String, Object> item : residentList) {
            if (item.get("primary_billing_account") != null && item.get("csg_billing_id") != null) {
                return item;
            }
        }
        
        // Priority 2: csg_billing_id
        for (Map<String, Object> item : residentList) {
            if (item.get("csg_billing_id") != null) {
                return item;
            }
        }
        
        // Priority 3: primary_billing_account
        for (Map<String, Object> item : residentList) {
            if (item.get("primary_billing_account") != null) {
                return item;
            }
        }
        
        return null;
    }
    
    private Map<String, Object> fetchElocData(String locationId, String token, Map<String, Object> secret) {
        String url = secretService.sget(secret, "eloc-api") + "/" + locationId + 
            "?components=" + secretService.sget(secret, "eloc-components");
        
        Map<String, String> headers = Map.of("Authorization", "Bearer " + token);
        
        return httpService.retryGetRequest("ELOC", url, headers, 30);
    }
    
    @SuppressWarnings("unchecked")
    private Map<String, Object> fetchFtnsData(String locationId, String token, Map<String, Object> secret) {
        String url = secretService.sget(secret, "ftns-api");
        
        String query = """
            query ($locationId: String!) {
              locationById(locationId: $locationId) {
                serviceAccount {
                  serviceAccountId
                  customerRelationship {
                    person {
                      personNode {
                        firstName
                        lastName
                      }
                    }
                    billingArrangement {
                      customerRelationshipId
                      billerAccountNumber
                      status
                      startDate
                      disconnectDate
                    }
                    customerSubtype
                  }
                }
              }
              premisePersistentEquipments(filter: {attribute: locationId, value: $locationId}) {
                premisePersistentEquipmentId
                serialNumber
                canonicalMake
                canonicalModel
                modelId
                location {
                  locationAttributes {
                    attributeName
                    attributeValue
                  }
                }
                attributes {
                  attributeId
                  attributeName
                  attributeType
                  attributeValue
                }
              }
            }""";
        
        Map<String, String> headers = Map.of(
            "Content-Type", "application/json",
            "Authorization", "Bearer " + token
        );
        
        Map<String, Object> variables = Map.of("locationId", locationId);
        
        Map<String, Object> payload = Map.of(
            "query", query,
            "variables", variables
        );
        
        try {
            String payloadJson = objectMapper.writeValueAsString(payload);
            return httpService.retryPostRequest("FTNS", url, headers, payloadJson, 30);
        } catch (Exception e) {
            LOG.error("Failed to serialize FTNS payload", e);
            return null;
        }
    }
    
    @SuppressWarnings("unchecked")
    private String[] processFtnsData(Map<String, Object> data) {
        String accountNumber = "";
        String status = null;
        String nameInFtns = "";
        List<String> macs = new ArrayList<>();
        int count = 0;
        
        if (data == null) return new String[]{"", "", "", ""};
        
        Map<String, Object> dataMap = (Map<String, Object>) data.get("data");
        if (dataMap == null) return new String[]{"", "", "", ""};
        
        Map<String, Object> locationById = (Map<String, Object>) dataMap.get("locationById");
        List<Map<String, Object>> serviceAccount = locationById != null ? 
            (List<Map<String, Object>>) locationById.get("serviceAccount") : new ArrayList<>();
        
        List<Map<String, Object>> ppeList = (List<Map<String, Object>>) dataMap.get("premisePersistentEquipments");
        
        if (serviceAccount == null) serviceAccount = new ArrayList<>();
        
        String[] statusKeywords = System.getenv().getOrDefault("ACCOUNT_STATUS_KEYWORD", "").split(",");
        Set<String> statusesOfInterest = Arrays.stream(statusKeywords)
            .map(String::trim)
            .filter(s -> !s.isEmpty())
            .collect(Collectors.toSet());
        
        for (Map<String, Object> item : serviceAccount) {
            Map<String, Object> customerRel = (Map<String, Object>) item.get("customerRelationship");
            if (customerRel == null) continue;
            
            // Process person name
            List<Map<String, Object>> personList = (List<Map<String, Object>>) customerRel.get("person");
            if (personList != null && !personList.isEmpty()) {
                Map<String, Object> personNode = (Map<String, Object>) personList.get(0).get("personNode");
                if (personNode != null) {
                    String firstName = Optional.ofNullable((String) personNode.get("firstName")).orElse("").trim();
                    String lastName = Optional.ofNullable((String) personNode.get("lastName")).orElse("").trim();
                    String fullName = (firstName + " " + lastName).trim();
                    
                    Object billingArrangementObj = customerRel.get("billingArrangement");
                    List<Map<String, Object>> billingArrangements = new ArrayList<>();
                    
                    if (billingArrangementObj instanceof List) {
                        billingArrangements = (List<Map<String, Object>>) billingArrangementObj;
                    } else if (billingArrangementObj instanceof Map) {
                        billingArrangements.add((Map<String, Object>) billingArrangementObj);
                    }
                    
                    Object customerSubtypeObj = customerRel.get("customerSubtype");
                    List<String> customerSubtype=new ArrayList<>();
                    if (customerSubtypeObj instanceof String) {
                        customerSubtype.add((String) customerSubtypeObj);
                    } else if (customerSubtypeObj instanceof List) {
                        customerSubtype = (List<String>) customerSubtypeObj;
                    }

                    String billerAccountNumber = null;
                    String entryStatus = null;
                    
                    if (billingArrangements.size() > 1) {
                        List<String> activeAccounts = new ArrayList<>();
                        for (Map<String, Object> entry : billingArrangements) {
                            if (entry.get("status") != null && statusesOfInterest.contains(entry.get("status")) && !customerSubtype.contains("BULKMASTER")) {
                                activeAccounts.add((String) entry.get("billerAccountNumber"));
                            }

                            if (!activeAccounts.isEmpty()) {
                                billerAccountNumber = String.join("/", activeAccounts);
                                entryStatus = "ACTIVE";
                            }
                        }
                    }else if (!billingArrangements.isEmpty()) {
                        Map<String, Object> firstEntry = billingArrangements.get(0);
                        billerAccountNumber = (String) firstEntry.get("billerAccountNumber");
                        entryStatus = (String) firstEntry.get("status");
                    }
                    
                    if (statusesOfInterest.contains(entryStatus) && !customerSubtype.contains("BULKMASTER")) {
                        count++;
                        if (count > 1) {
                            accountNumber = billerAccountNumber + "/" + accountNumber;
                            status = null;
                            nameInFtns = "";
                        } else {
                            accountNumber = billerAccountNumber != null ? billerAccountNumber : "";
                            status = entryStatus;
                            nameInFtns = fullName;
                        }
                    }
                }
            }
        }
        
        // Process MAC addresses
        if (ppeList != null) {
            for (Map<String, Object> ppe : ppeList) {
                List<Map<String, Object>> attributes = (List<Map<String, Object>>) ppe.get("attributes");
                if (attributes != null) {
                    for (Map<String, Object> attr : attributes) {
                        if ("cMMacAddress".equals(attr.get("attributeName"))) {
                            String macValue = (String) attr.get("attributeValue");
                            if (macValue != null) {
                                macs.add(macValue);
                            }
                            break;
                        }
                    }
                }
            }
        }
        
        String macAddress = String.join(" / ", macs);
        return new String[]{accountNumber, status, nameInFtns, macAddress};
    }

    private boolean isHexGarbage(String s) {
        if (s == null || s.isEmpty()) return false;
        return s.length() > 20 && s.matches("[A-Fa-f0-9]+");
    }
}