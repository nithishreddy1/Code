package com.comcast.service;

import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProvider;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProviderClientBuilder;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthRequest;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthResult;
import com.amazonaws.services.cognitoidp.model.AuthFlowType;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class TokenService {
    private static final Logger LOG = LoggerFactory.getLogger(TokenService.class);
    private static final Map<String, String> TOKEN_CACHE = new ConcurrentHashMap<>();
    @Autowired
    private SecretService secretService;

    @Autowired
    private HttpService httpService;
    
    public static void clearCache() {
        TOKEN_CACHE.clear();
    }
    
    private String getOrCacheToken(String key, TokenFetcher fetcher) {
        String cached = TOKEN_CACHE.get(key);
        if (cached != null) {
            return cached;
        }
        
        String token = fetcher.fetch();
        if (token != null) {
            TOKEN_CACHE.put(key, token);
        }
        return token;
    }
    
    public String getXrayToken(Map<String, Object> secret) {
        return getOrCacheToken("xray", () -> fetchXrayToken(secret));
    }
    
    public String getOdpToken(Map<String, Object> secret) {
        return getOrCacheToken("odp", () -> fetchOdpToken(secret));
    }
    
    public String getRpilToken(Map<String, Object> secret) {
        return getOrCacheToken("rpil", () -> fetchRpilToken(secret));
    }
    
    public String getEntToken(Map<String, Object> secret) {
        return getOrCacheToken("ent", () -> fetchEntToken(secret));
    }
    
    public String getFtsToken(Map<String, Object> secret) {
        return getOrCacheToken("ftns", () -> fetchFtnsToken(secret));
    }
    
    public String getElocToken(Map<String, Object> secret) {
        return getOrCacheToken("eloc", () -> fetchElocToken(secret));
    }
    
    private String fetchXrayToken(Map<String, Object> secret) {
        String url = secretService.sget(secret, "sat-token-url");
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "text/plain");
        headers.put("X-Client-Id", secretService.sget(secret, "X-Client-Id"));
        headers.put("X-Client-Secret", secretService.sget(secret, "X-Client-Secret"));
        
        Map<String, Object> result = httpService.retryPostRequest("X-RAY", url, headers, null);
        return result != null ? (String) result.get("access_token") : null;
    }
    
    private String fetchOdpToken(Map<String, Object> secret) {
        String url = secretService.sget(secret, "sat-token-url");
        Map<String, String> headers = new HashMap<>();
        headers.put("X-Client-Id", secretService.sget(secret, "odp-client-id"));
        headers.put("X-Client-Secret", secretService.sget(secret, "odp-client-secret"));
        
        Map<String, Object> result = httpService.retryPostRequest("ODP", url, headers, null);
        return result != null ? (String) result.get("access_token") : null;
    }
    
    private String fetchRpilToken(Map<String, Object> secret) {
        String url = secretService.sget(secret, "sat-token-url");
        Map<String, String> headers = new HashMap<>();
        headers.put("X-Client-Id", secretService.sget(secret, "rpil-client-id"));
        headers.put("X-Client-Secret", secretService.sget(secret, "rpil-client-secret"));
        
        Map<String, Object> result = httpService.retryPostRequest("RPIL", url, headers, null);
        return result != null ? (String) result.get("access_token") : null;
    }
    
    private String fetchEntToken(Map<String, Object> secret) {
        String url = secretService.sget(secret, "sat-token-url");
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "text/plain");
        headers.put("X-Client-Id", secretService.sget(secret, "ent-client-id"));
        headers.put("X-Client-Secret", secretService.sget(secret, "ent-client-secret"));
        
        Map<String, Object> result = httpService.retryPostRequest("ENTITLEMENT", url, headers, null);
        return result != null ? (String) result.get("access_token") : null;
    }
    
    private String fetchFtnsToken(Map<String, Object> secret) {
        String base = secretService.sget(secret, "ftns-sat-url");
        if (base == null) {
            LOG.error("FTNS token url missing");
            return null;
        }
        
        String url = String.format("%s?client_id=%s&client_secret=%s&grant_type=%s&scope=%s",
            base,
            secretService.sget(secret, "sat-client-id"),
            secretService.sget(secret, "sat_client_secret"),
            secretService.sget(secret, "grant_type"),
            secretService.sget(secret, "ftns_scope"));
            
        Map<String, Object> result = httpService.retryPostRequest("FTNS", url, null, null);
        return result != null ? (String) result.get("access_token") : null;
    }
    
    private String fetchElocToken(Map<String, Object> secret) {
        String base = secretService.sget(secret, "ftns-sat-url");
        if (base == null) {
            LOG.error("ELOC token url missing");
            return null;
        }
        
        String url = String.format("%s?client_id=%s&client_secret=%s&grant_type=%s&scope=%s",
            base,
            secretService.sget(secret, "sat-client-id"),
            secretService.sget(secret, "sat_client_secret"),
            secretService.sget(secret, "grant_type"),
            secretService.sget(secret, "eloc_scope"));
            
        Map<String, Object> result = httpService.retryPostRequest("ELOC", url, null, null);
        return result != null ? (String) result.get("access_token") : null;
    }
    
    public String getProdToken(Map<String, Object> secret) {
        return getOrCacheToken("prod", () -> fetchProdToken(secret));
    }
    
    private String fetchProdToken(Map<String, Object> secret) {
        try {
            AWSCognitoIdentityProvider client = AWSCognitoIdentityProviderClientBuilder.standard()
                .withRegion(secretService.sget(secret, "region_name"))
                .build();
                
            Map<String, String> authParams = new HashMap<>();
            authParams.put("USERNAME", secretService.sget(secret, "username"));
            authParams.put("PASSWORD", secretService.sget(secret, "password"));
            
            AdminInitiateAuthRequest request = new AdminInitiateAuthRequest()
                .withUserPoolId(secretService.sget(secret, "user_pool_id"))
                .withClientId(secretService.sget(secret, "client_id"))
                .withAuthFlow(AuthFlowType.ADMIN_USER_PASSWORD_AUTH)
                .withAuthParameters(authParams);
                
            AdminInitiateAuthResult response = client.adminInitiateAuth(request);
            return response.getAuthenticationResult().getIdToken();
            
        } catch (Exception e) {
            LOG.error("[PROD] Failed to retrieve token", e);
            return null;
        }
    }
    
    @FunctionalInterface
    private interface TokenFetcher {
        String fetch();
    }
}