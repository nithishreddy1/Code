package com.comcast.service;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class JsonService {
    private static final Logger LOG = LoggerFactory.getLogger(JsonService.class);
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    private AmazonS3 s3Client;

    public void saveToJson(List<Map<String, Object>> dataList, String propertyName) {
        if (dataList == null || dataList.isEmpty()) {
            LOG.info("No data to write.");
            return;
        }

        String filename = "/tmp/" + propertyName + "_Audit.json";

        try {
            String jsonContent = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(dataList);
            uploadToS3(jsonContent, propertyName);
        } catch (IOException e) {
            LOG.error("Failed to create JSON file", e);
        }
    }

    private void uploadToS3(String jsonContent, String propertyName) {
        String s3Bucket = System.getenv("Bucket");


        if (s3Bucket == null ) {
            LOG.warn("S3 bucket or prefix not configured, skipping upload");
            return;
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-YYYY");
        String folderName = dateFormat.format(new Date());
        String s3Key = folderName + propertyName + "_Audit.json";

        try {
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentType("application/json");
            metadata.setContentLength(jsonContent.getBytes().length);

            ByteArrayInputStream inputStream = new ByteArrayInputStream(jsonContent.getBytes());
            s3Client.putObject(s3Bucket, s3Key, inputStream, metadata);

            LOG.info("JSON file uploaded to s3://{}/{}", s3Bucket, s3Key);
        } catch (Exception e) {
            LOG.error("S3 upload failed", e);
        }
    }
}