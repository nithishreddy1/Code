package com.comcast.model;

import java.util.List;
import java.util.Map;

public record ApiResponse(
    String status,
    String message,
    String propertyName,
    Integer totalUnits,
    List<Map<String, Object>> data
) {
    public static ApiResponse success(String message, List<Map<String, Object>> data, String propertyName) {
        return new ApiResponse("success", message, propertyName, data.size(), data);
    }
    
    public static ApiResponse error(String message) {
        return new ApiResponse("error", message, null, null, null);
    }
}