import asyncio
import os
import re
import requests
import aiohttp
import certifi
import ssl
import xml.etree.ElementTree as ET
import pandas as pd
import boto3
import json
import time
import logging
import random
from typing import Any, Dict, Optional, List

LOG = logging.getLogger()
LOG.setLevel(logging.INFO)

SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where())

# Retry configuration
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))
BACKOFF_FACTOR = float(os.getenv("BACKOFF_FACTOR", "1.5"))
GLOBAL_CONCURRENCY = int(os.getenv("GLOBAL_CONCURRENCY", "10"))
ASYNC_SEMAPHORE = asyncio.Semaphore(GLOBAL_CONCURRENCY)

TOKEN_CACHE: Dict[str, Any] = {}

def sget(secret: Dict[str, Any], key: str, default=None):
    return secret.get(key, default) if secret else default

def jittered_backoff(attempt: int) -> float:
    base = BACKOFF_FACTOR ** attempt
    return base + random.uniform(0, base)

def retry_post_request(name: str, url: str, headers: Optional[Dict[str, str]], payload: Optional[Any] = None, timeout: int = 10):
    if not url:
        LOG.error("[%s] No URL provided", name)
        return None

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = requests.post(url, headers=headers, data=payload, timeout=timeout)
            status = resp.status_code
            if status == 200:
                LOG.info("[%s] Token fetched successfully at attempt %d (HTTP %d)", name, attempt, status)
                return resp.json()

            if status in RETRYABLE_STATUS_CODES:
                LOG.warning("[%s] Attempt %d: HTTP %d - retrying...", name, attempt, status)
            else:
                LOG.error("[%s] Non-retryable HTTP %d - body: %s", name, status, resp.text)
                break

        except requests.exceptions.RequestException as e:
            LOG.warning("[%s] Attempt %d: RequestException: %s", name, attempt, e)

        # Backoff before next attempt
        if attempt < MAX_RETRIES:
            sleep_for = jittered_backoff(attempt)
            time.sleep(sleep_for)

    LOG.error("[%s] All %d retries failed.", name, MAX_RETRIES)
    return None

def get_or_cache_token(key: str, fetcher_callable):
    if key in TOKEN_CACHE and TOKEN_CACHE[key]:
        return TOKEN_CACHE[key]

    token = fetcher_callable()
    TOKEN_CACHE[key] = token
    return token

def _fetch_xray_token(secret: Dict[str, Any]):
    url = sget(secret, 'sat-token-url')
    headers = {
        'Content-Type': 'text/plain',
        'X-Client-Id': sget(secret, 'X-Client-Id'),
        'X-Client-Secret': sget(secret, 'X-Client-Secret')
    }
    result = retry_post_request('X-RAY', url, headers)
    return (result.get('access_token') if result else None)

def getXrayToken(secret: Dict[str, Any]):
    return get_or_cache_token('xray', lambda: _fetch_xray_token(secret))

def _fetch_odp_token(secret: Dict[str, Any]):
    url = sget(secret, 'sat-token-url')
    headers = {
        'X-Client-Id': sget(secret, 'odp-client-id'),
        'X-Client-Secret': sget(secret, 'odp-client-secret')
    }
    result = retry_post_request('ODP', url, headers)
    return (result.get('access_token') if result else None)

def getodpToken(secret: Dict[str, Any]):
    return get_or_cache_token('odp', lambda: _fetch_odp_token(secret))

def _fetch_rpil_token(secret: Dict[str, Any]):
    url = sget(secret, 'sat-token-url')
    headers = {
        'X-Client-Id': sget(secret, 'rpil-client-id'),
        'X-Client-Secret': sget(secret, 'rpil-client-secret')
    }
    result = retry_post_request('RPIL', url, headers)
    return (result.get('access_token') if result else None)

def getRpilToken(secret: Dict[str, Any]):
    return get_or_cache_token('rpil', lambda: _fetch_rpil_token(secret))

def _fetch_ent_token(secret: Dict[str, Any]):
    url = sget(secret, 'sat-token-url')
    headers = {
        'Content-Type': 'text/plain',
        'X-Client-Id': sget(secret, 'ent-client-id'),
        'X-Client-Secret': sget(secret, 'ent-client-secret')
    }
    result = retry_post_request('ENTITLEMENT', url, headers)
    return (result.get('access_token') if result else None)

def getEntToken(secret: Dict[str, Any]):
    return get_or_cache_token('ent', lambda: _fetch_ent_token(secret))

def _fetch_ftns_token(secret: Dict[str, Any]):
    base = sget(secret, 'ftns-sat-url')
    client_id = sget(secret, 'sat-client-id')
    client_secret = sget(secret, 'sat_client_secret')
    grant_type = sget(secret, 'grant_type')
    scope = sget(secret, 'ftns_scope')

    if not base:
        LOG.error('FTNS token url missing')
        return None

    url = f"{base}?client_id={client_id}&client_secret={client_secret}&grant_type={grant_type}&scope={scope}"
    result = retry_post_request('FTNS', url, None)
    return (result.get('access_token') if result else None)

def getFtsToken(secret: Dict[str, Any]):
    return get_or_cache_token('ftns', lambda: _fetch_ftns_token(secret))

def _fetch_eloc_token(secret: Dict[str, Any]):
    base = sget(secret, 'ftns-sat-url')
    client_id = sget(secret, 'sat-client-id')
    client_secret = sget(secret, 'sat_client_secret')
    grant_type = sget(secret, 'grant_type')
    scope = sget(secret, 'eloc_scope')
    if not base:
        LOG.error('ELOC token url missing')
        return None
    url = f"{base}?client_id={client_id}&client_secret={client_secret}&grant_type={grant_type}&scope={scope}"
    result = retry_post_request('ELOC', url, None)
    return (result.get('access_token') if result else None)

def getElocToken(secret: Dict[str, Any]):
    return get_or_cache_token('eloc', lambda: _fetch_eloc_token(secret))

def getProdToken(secret: Dict[str, Any]):
    aws_secret_access_key = sget(secret, 'aws_secret_access_key')
    aws_access_key_id = sget(secret, 'aws_access_key_id')
    user_pool_id = sget(secret, 'user_pool_id')
    client_id = sget(secret, 'client_id')
    region_name = sget(secret, 'region_name')
    username = sget(secret, 'username')
    password = sget(secret, 'password')

    try:
        client = boto3.client('cognito-idp',
                              aws_access_key_id=aws_access_key_id,
                              aws_secret_access_key=aws_secret_access_key,
                              region_name=region_name)

        response = client.admin_initiate_auth(
            UserPoolId=user_pool_id,
            ClientId=client_id,
            AuthFlow='ADMIN_USER_PASSWORD_AUTH',
            AuthParameters={'USERNAME': username, 'PASSWORD': password}
        )
        token = response['AuthenticationResult']['IdToken']
        TOKEN_CACHE['prod'] = token
        return token

    except client.exceptions.NotAuthorizedException as e:
        LOG.error('[PROD] Authentication failed: %s', e)
    except client.exceptions.UserNotFoundException as e:
        LOG.error('[PROD] User not found: %s', e)
    except Exception as e:
        LOG.exception('[PROD] Cognito token fetch failed')

    LOG.error('[PROD] Failed to retrieve token.')
    return None

async def async_request_with_retries(session: aiohttp.ClientSession, method: str, url: str, *, semaphore,
                                     headers: Optional[Dict[str, str]] = None,
                                     json_payload: Optional[Any] = None,
                                     params: Optional[Dict[str, str]] = None,
                                     retries: int = MAX_RETRIES,
                                     timeout: int = 30) -> Optional[Any]:

    if not url:
        LOG.error('async_request: no url provided')
        return None

    last_exc = None
    for attempt in range(1, retries + 1):
        try:
            async with semaphore:
                async with session.request(method, url, headers=headers, json=json_payload, params=params, timeout=timeout) as resp:
                    status = resp.status
                    if status == 200:
                        try:
                            return await resp.json()
                        except Exception:
                            return await resp.text()

                    if status in RETRYABLE_STATUS_CODES:
                        LOG.warning('Attempt %d: HTTP %d for %s %s - will retry', attempt, status, method, url)
                    else:
                        LOG.error('Non-retryable HTTP %d for %s %s - body: %s', status, method, url, await resp.text())
                        return None

        except Exception as e:
            last_exc = e
            LOG.warning('Attempt %d: Request exception for %s %s: %s', attempt, method, url, e)

        if attempt < retries:
            sleep_for = jittered_backoff(attempt)
            await asyncio.sleep(sleep_for)

    LOG.error('All %d async retries failed for %s %s; last exception: %s', retries, method, url, last_exc)
    return None

def getUnitsFromProperty(property_vendor_id: str, secret: Dict[str, Any]):
    url = f"{sget(secret, 'xc2-pms-units')}/{property_vendor_id}/units"
    headers = {"Authorization": f"Bearer {getProdToken(secret)}"}

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = requests.get(url, headers=headers, timeout=10)
            if resp.status_code == 200:
                return resp.json()
            if resp.status_code in RETRYABLE_STATUS_CODES:
                LOG.warning('getUnitsFromProperty retry %d HTTP %d', attempt, resp.status_code)
            else:
                LOG.error('getUnitsFromProperty non-retryable HTTP %d - %s', resp.status_code, resp.text)
                break
        except requests.RequestException as e:
            LOG.warning('getUnitsFromProperty attempt %d exception: %s', attempt, e)
        if attempt < MAX_RETRIES:
            time.sleep(jittered_backoff(attempt))
    return None

def processResidentList(residentList: Optional[List[Dict[str, Any]]]):
    for item in residentList or []:
        if item.get('primary_billing_account') and item.get('csg_billing_id'):
            return item
    for item in residentList or []:
        if item.get('csg_billing_id'):
            return item
    for item in residentList or []:
        if item.get('primary_billing_account'):
            return item
    return None

async def fetch_eloc_data(session: aiohttp.ClientSession, location_id: str, token: str, secret: Dict[str, Any]):
    url = f"{sget(secret, 'eloc-api')}/{location_id}?components={sget(secret, 'eloc-components')}"
    headers = {"Authorization": f"Bearer {token}"}
    semaphore = asyncio.Semaphore(2)
    return await async_request_with_retries(session, 'GET', url, headers=headers, semaphore= semaphore)

async def fetch_ftnc_data(session: aiohttp.ClientSession, param: str, ftns_token: str, secret: Dict[str, Any]):
    url = f"{sget(secret, 'ftns-api')}"
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {ftns_token}"}

    body =  """query ($locationId: String!) {
                  locationById(locationId: $locationId) {
                    serviceAccount {
                      serviceAccountId
                      customerRelationship {
                        person {
                          personNode {
                            firstName
                            lastName
                          }
                        }
                        billingArrangement {
                          customerRelationshipId
                          billerAccountNumber
                          status
                          startDate
                          disconnectDate
                        }
                        customerSubtype
                      }
                    }
                  }
                  premisePersistentEquipments(filter: {attribute: locationId, value: $locationId}) {
                    premisePersistentEquipmentId
                    serialNumber
                    canonicalMake
                    canonicalModel
                    modelId
                    location {
                      locationAttributes {
                        attributeName
                        attributeValue
                      }
                    }
                    attributes {
                      attributeId
                      attributeName
                      attributeType
                      attributeValue
                    }
                  }
        }"""

    variables = {"locationId": f"{param}"}
    return await async_request_with_retries(session, 'POST', url, headers=headers, json_payload={"query": body, 'variables': variables}, semaphore=ASYNC_SEMAPHORE)

def processFtnsData(serviceAccount: Any, ppe_list: Any):
    account_number = ""
    status = None
    nameInFtns = ""
    count = 0

    if not serviceAccount:
        serviceAccount = []

    for item in serviceAccount:
        customer_rel = item.get('customerRelationship', {})
        if not customer_rel:
            continue

        person_list = customer_rel.get('person', [])
        person_node = person_list[0].get('personNode', {}) if person_list and isinstance(person_list[0], dict) else {}
        first_name = (person_node.get('firstName') or '').strip()
        last_name = (person_node.get('lastName') or '').strip()
        full_name = f"{first_name} {last_name}".strip()

        billing_arrangements = customer_rel.get('billingArrangement', []) or []
        if not isinstance(billing_arrangements, list):
            billing_arrangements = [billing_arrangements]

        customer_subtype = customer_rel.get('customerSubtype') or []
        if isinstance(customer_subtype, str):
            customer_subtype = [customer_subtype]

        statuses_of_interest = [keyword.strip() for keyword in os.getenv('ACCOUNT_STATUS_KEYWORD', '').split(',') if keyword.strip()]

        if len(billing_arrangements) > 1:
            active_accounts = [entry.get('billerAccountNumber') for entry in billing_arrangements if (entry.get('status') in statuses_of_interest and (not customer_subtype or 'BULKMASTER' not in customer_subtype))]
            if active_accounts:
                biller_account_number = '/'.join(active_accounts)
                entry_status = 'ACTIVE'
            else:
                biller_account_number = None
                entry_status = None
        else:
            first_entry = billing_arrangements[0] if billing_arrangements else {}
            biller_account_number = first_entry.get('billerAccountNumber') if isinstance(first_entry, dict) else None
            entry_status = first_entry.get('status') if isinstance(first_entry, dict) else None

        if entry_status in statuses_of_interest and (not customer_subtype or 'BULKMASTER' not in customer_subtype):
            count += 1
            if count > 1:
                account_number = f"{biller_account_number}/{account_number}"
                status = None
                nameInFtns = ''
            else:
                account_number = biller_account_number
                status = entry_status
                nameInFtns = full_name

    macs = []
    if ppe_list:
        for ppe in ppe_list:
            for attr in ppe.get('attributes', []) or []:
                if attr.get('attributeName') == 'cMMacAddress':
                    if attr.get('attributeValue'):
                        macs.append(attr.get('attributeValue'))
                    break

    macAddress = ' / '.join(macs)
    return account_number or '', status, nameInFtns or '', macAddress

async def process_units_async(units_list: List[Dict[str, Any]], eloc_token: str, ftns_token: str, secret: Dict[str, Any]):
    result_list = []
    connector = aiohttp.TCPConnector(ssl=SSL_CONTEXT)
    async with aiohttp.ClientSession(connector=connector) as session:
        eloc_tasks = [fetch_eloc_data(session, unit.get('location_id'), eloc_token, secret) for unit in units_list]
        ftns_tasks = [fetch_ftnc_data(session, unit.get('location_id'), ftns_token, secret) for unit in units_list]

        eloc_results = await asyncio.gather(*eloc_tasks)
        ftns_results = await asyncio.gather(*ftns_tasks)

        for i, unit in enumerate(units_list):
            unitName = unit.get('name')
            address_list = unit.get('address', [])
            locaton_id = unit.get('location_id')
            unitHouseKey = unit.get('house_key')
            unitTypeInXc2 = unit.get('type')
            streetAddress = address_list[0].get('street_address') if address_list else 'NA'

            print("processing for location id : ", locaton_id )

            cbFlagEnableInXc2 = 'Yes' if unitTypeInXc2 == 'CB' else 'No'
            xc2ResidentName = ''
            billingAccountInXc2 = ''
            nameMatch = 'No'
            accountMatch = 'No'
            cpgFlag = 'No'

            residentDetails = processResidentList(unit.get('residents'))
            if residentDetails:
                first_name = (residentDetails.get('first_name') or '').strip()
                last_name = (residentDetails.get('last_name') or '').strip()
                xc2ResidentName = f"{first_name} {last_name}".strip()
                billingAccountInXc2 = residentDetails.get('csg_billing_id') or ''

            eloc_data = eloc_results[i]
            dropCell = 'NA'
            if isinstance(eloc_data, dict):
                csgDetailsList = eloc_data.get('billingDetailsInfo', {}).get('csgDetails', []) or []
                if csgDetailsList and isinstance(csgDetailsList[0], dict):
                    dropCell = csgDetailsList[0].get('cell', 'NA')

            LOG.info('processing for location id : %s', locaton_id)

            data = ftns_results[i]
            serviceAccount = (data.get('data', {}).get('locationById', {}).get('serviceAccount', [])) if isinstance(data, dict) else []
            ppe_list = (data.get('data', {}).get('premisePersistentEquipments', [])) if isinstance(data, dict) else []

            accountNumberInFtns, statusInFtns, nameInFtns, mac = processFtnsData(serviceAccount, ppe_list)

            if (xc2ResidentName or '').lower() and (nameInFtns or '').lower() and (xc2ResidentName or '').lower() == (nameInFtns or '').lower():
                nameMatch = 'Yes'

            masa = 'Yes' if '/' in accountNumberInFtns else 'No'
            if (dropCell or '') == 'CPG':
                cpgFlag = 'Yes'
            if billingAccountInXc2 and billingAccountInXc2 == accountNumberInFtns and masa == 'No':
                accountMatch = 'Yes'

            result = {
                'Unit Name': unitName,
                'House Key': unitHouseKey,
                'Location ID': locaton_id,
                'Address Line 1': streetAddress,
                'Drop Cell': dropCell,
                'MASA': masa,
                'CxB Badge on Servicability Page': cpgFlag,
                'XC2 Enabled': cbFlagEnableInXc2,
                'XC2 Resident Name': (xc2ResidentName or '').lower(),
                'E360 Customer Name': (nameInFtns or '').lower(),
                'Name Match?': nameMatch,
                'E360 Account Number': accountNumberInFtns,
                'XC2 Account Number': billingAccountInXc2,
                'Match?': accountMatch,
                'OnRamp Device': mac
            }
            result_list.append(result)

    return result_list

async def process_result_async(result_list: List[Dict[str, Any]], ent_token: str, secret: Dict[str, Any]):
    connector = aiohttp.TCPConnector(ssl=SSL_CONTEXT)
    semaphore_d = asyncio.Semaphore(2)

    async with aiohttp.ClientSession(connector=connector) as session:

        async def fetch_ent_data_local(param: str):
            api_url = f"{sget(secret, 'entitlement-api')}/account"
            params = {"billingAccountNum": param}
            headers = {
                'Accept': '*/*',
                'x-sourcesystemid': sget(secret, 'entitlement-sourcesystemid'),
                'Authorization': f"Bearer {ent_token}"
            }

            return await async_request_with_retries(session, 'GET', api_url, headers=headers, params=params,semaphore=semaphore_d)

        tasks = [fetch_ent_data_local(data.get('E360 Account Number')) if data.get('Match?') == 'Yes' else None for data in result_list]
        valid_tasks = [t for t in tasks if t is not None]
        fetched_results = await asyncio.gather(*valid_tasks) if valid_tasks else []

        results = []
        fetch_index = 0
        for task in tasks:
            if task is None:
                results.append(None)
            else:
                results.append(fetched_results[fetch_index])
                fetch_index += 1

        enriched_results = []
        cbRateCode = [keyword.strip() for keyword in os.getenv('CB_RATE_CODE', '').split(',') if keyword.strip()]

        for data_item, ent_data in zip(result_list, results):
            rateCode = ''
            if ent_data is None:
                rateCode = ''
            else:
                xml_text = None
                if isinstance(ent_data, str):
                    xml_text = ent_data
                elif isinstance(ent_data, dict):
                    xml_text = ent_data.get('text') or ent_data.get('xml')

                if xml_text:
                    try:
                        root = ET.fromstring(xml_text)
                        rate_codes_element = root.find('.//rateCodes')
                        if rate_codes_element is not None and rate_codes_element.text:
                            rate_codes = rate_codes_element.text.split()
                            if all(keyword in rate_codes for keyword in cbRateCode):
                                rateCode = 'Yes'
                    except Exception:
                        LOG.exception('Failed to parse entitlement XML')

            data_item['CxB Badge on Customer in E360'] = rateCode
            data_item['CxB Rate Codes'] = rateCode
            enriched_results.append(data_item)

        return enriched_results

async def process_xray_async(e_list: List[Dict[str, Any]], xrayToken: str, rpilToken: str, amenitySSID: Optional[str], unit_list: List[Dict[str, Any]], odpToken: str, secret: Dict[str, Any]):
    connector = aiohttp.TCPConnector(ssl=SSL_CONTEXT)
    async with aiohttp.ClientSession(connector=connector) as session:
        semaphore_s = asyncio.Semaphore(3)

        async def fetch_xray_data(mac: str):
            url = (f"{sget(secret, 'xray-api')}/{mac}?partners={sget(secret, 'xray-partners')}"
                   f"&includeAllDevices={sget(secret, 'xray-includeAllDevices')}&excludeX1DeleteDevices={sget(secret, 'xray-excludeX1DeleteDevices')}")
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f"Bearer {xrayToken}",
                'Correlation-Id': sget(secret, 'xray-correlation- Id'),
                'Accept': 'application/json'
            }

            return await async_request_with_retries(session, 'GET', url, headers=headers, semaphore= semaphore_s)

        async def fetch_rpil_data(mac: str):
            url = f"{sget(secret, 'rpil-api')}/?managementMac={mac}&parameterList={sget(secret, 'rpil-parameterList')}"
            headers = {'Content-Type': 'application/json', 'Authorization': f"Bearer {rpilToken}", 'Accept': 'application/json'}

            return await async_request_with_retries(session, 'GET', url, headers=headers, semaphore= semaphore_s)

        async def fetch_connected_devices(mac: str):
            converted_mac = mac.replace(':', '') if mac else ''
            url = f"{sget(secret, 'odp-api')}/{converted_mac}/devices/summary"
            headers = {'Content-Type': 'application/json', 'Authorization': f"Bearer {odpToken}", 'Accept': 'application/json'}

            return await async_request_with_retries(session, 'GET', url, headers=headers,semaphore= semaphore_s)

        tasks_xray = [fetch_xray_data(data.get('OnRamp Device')) if data.get('OnRamp Device') and '/' not in data.get('OnRamp Device') else None for data in e_list]
        tasks_rpil = [fetch_rpil_data(data.get('OnRamp Device')) if data.get('OnRamp Device') and '/' not in data.get('OnRamp Device') else None for data in e_list]
        tasks_odp = [fetch_connected_devices(data.get('OnRamp Device')) if data.get('OnRamp Device') and '/' not in data.get('OnRamp Device') else None for data in e_list]

        # gather only valid tasks
        valid_xray = [t for t in tasks_xray if t is not None]
        valid_rpil = [t for t in tasks_rpil if t is not None]
        valid_odp = [t for t in tasks_odp if t is not None]

        xray_results = await asyncio.gather(*valid_xray) if valid_xray else []
        rpil_results = await asyncio.gather(*valid_rpil) if valid_rpil else []
        odp_results = await asyncio.gather(*valid_odp) if valid_odp else []

        # reconstitute lists to original order
        def reconstitute(tasks_template, fetched):
            res = []
            idx = 0
            for t in tasks_template:
                if t is None:
                    res.append(None)
                else:
                    res.append(fetched[idx])
                    idx += 1
            return res

        xray_Result = reconstitute(tasks_xray, xray_results)
        rpil_result = reconstitute(tasks_rpil, rpil_results)
        odp_result = reconstitute(tasks_odp, odp_results)

        final_List = []
        for i, data in enumerate(e_list):
            data = dict(data)  # copy to avoid mutating input
            json_data = xray_Result[i]
            unit = unit_list[i]
            rpil_data = rpil_result[i]
            device_data = odp_result[i]

            deviceAssignToCustomer = 'No'
            connectDevice = 'No'

            # xray handling
            if json_data is None:
                data['OnRamp Device Assigned to Customer'] = 'No'
                data['Device X1 Status (xRay)'] = ''
            else:
                items = (json_data.get('data', {}).get('items', [])) if isinstance(json_data, dict) else []
                if items:
                    first_item = items[0]
                    billing_id = first_item.get('x1BillingId')
                    devices = first_item.get('devices', [])
                    device_status = devices[0].get('x1Status') if devices else None

                    if data.get('Match?') == 'Yes' and data.get('E360 Account Number') == billing_id:
                        deviceAssignToCustomer = 'Yes'

                    data['OnRamp Device Assigned to Customer'] = deviceAssignToCustomer
                    data['Device X1 Status (xRay)'] = device_status or ''

            # RPIL processing (defensive checks)
            if isinstance(rpil_data, dict):
                unit_ssid = getSSID(unit.get('devices'))
                ssidRpil = ''
                factoryDefault = ''
                amenitySSIDRpil = ''
                guestRpil = ''
                bootfile = ''
                for param in rpil_data.get('parameters', []) or []:
                    if param.get('key') == str(os.getenv('RPIL_SSID_KEY')):
                        ssidRpil = param.get('value') or ''
                    elif param.get('key') == str(os.getenv('RPIL_FACTORY_DEFAULT_KEY')):
                        factoryDefault = param.get('value') or ''
                    elif param.get('key') == str(os.getenv('RPIL_AMENITY_SSID_KEY')):
                        amenitySSIDRpil = param.get('value') or ''
                    elif param.get('key') == str(os.getenv('RPIL_GUEST_SSID_KEY')):
                        guestRpil = param.get('value') or ''
                    elif param.get('key') == str(os.getenv('RPIL_BOOTFILE_KEY')):
                        bootfile = param.get('value') or ''

                ssidPersonalized = 'No'
                ssidSet = 'No'

                # safe lower comparisons
                if (ssidRpil or '').lower() == (factoryDefault or '').lower():
                    ssidPersonalized = 'No'
                    ssidSet = 'No'
                elif (unit_ssid or '').lower() == (ssidRpil or '').lower() and (ssidRpil or ''):
                    ssidPersonalized = 'No'
                    ssidSet = 'Yes'
                elif is_hex_garbage(ssidRpil):
                    ssidPersonalized = 'No'
                    ssidSet = 'No'
                else:
                    if ssidRpil:
                        ssidPersonalized = 'Yes'
                        ssidSet = 'Yes'

                amenityNetwork = 'Yes' if (amenitySSIDRpil or '').lower() == (amenitySSID or '').lower() and amenitySSID else 'No'
                guestNetwork = 'Yes' if (guestRpil or '').lower() == (os.environ.get('GUEST_CONST') or '').lower() and guestRpil else 'No'

                non_surfable_keywords = [keyword.strip().lower() for keyword in os.getenv('NON_SURFABLE_KEYWORDS', '').split(',') if keyword.strip()]
                surfable_boot_file = 'Yes'
                if bootfile and any(keyword in bootfile.lower() for keyword in non_surfable_keywords):
                    surfable_boot_file = 'No'

                data['OnRamp Device Online'] = 'Yes'
                data['Surfable Bootfile'] = surfable_boot_file
                data['In-unit Network Enabled'] = ssidSet
                data['In-unit Network Personalized'] = ssidPersonalized
                data['Amenity Networks Enabled'] = amenityNetwork
                data['Guest Network Enabled'] = guestNetwork
            else:
                data['OnRamp Device Online'] = 'No'
                data['Surfable Bootfile'] = ''
                data['In-unit Network Enabled'] = ''
                data['In-unit Network Personalized'] = ''
                data['Amenity Networks Enabled'] = ''
                data['Guest Network Enabled'] = ''

            # ODP connected devices
            if isinstance(device_data, dict):
                data_array = device_data.get('data')
                if data_array and len(data_array) >= 1:
                    connectDevice = 'Yes'

            data['Active Devices Connected'] = connectDevice
            final_List.append(data)

        return final_List

def getPropertyInfo(property_vendor_id: str, secret: Dict[str, Any]):
    url = f"{sget(secret, 'xc2-identity')}/{property_vendor_id}"
    headers = {"Authorization": f"Bearer {getProdToken(secret)}"}
    try:
        resp = requests.get(url, headers=headers, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            name = data.get('name')
            ssid_value = None
            for prop in data.get('extended_properties', []) or []:
                if prop.get('identifier_type') == 'AMENITYNETWORK_DEFAULTSSID':
                    ssid_value = prop.get('value')
                    break
            return ssid_value, name
        LOG.error('getPropertyInfo returned HTTP %s: %s', resp.status_code, resp.text)
    except Exception:
        LOG.exception('getPropertyInfo failed')
    return None, None

def is_hex_garbage(s: Optional[str]) -> bool:
    if not s:
        return False
    return len(s) > 20 and re.fullmatch(r'[A-Fa-f0-9]+', s) is not None

def get_secret(secret_name: str, region_name: str):
    client = boto3.client('secretsmanager', region_name=region_name)
    response = client.get_secret_value(SecretId=secret_name)
    if 'SecretString' in response:
        return json.loads(response['SecretString'])
    else:
        return json.loads(response['SecretBinary'])

def getSSID(param: List[Dict[str, Any]]):
    for item in param or []:
        if item.get('default_ssid'):
            return item.get('default_ssid')
    return None

def save_to_csv(data_list: List[Dict[str, Any]], property_name: str):
    filename = f"/tmp/{property_name} Audit.xlsx"

    if not data_list:
        print("No data to write.")
        return

    df = pd.DataFrame(data_list)

    if 'xc2BillingAccount' in df.columns:
        df['xc2BillingAccount'] = df['xc2BillingAccount'].astype(str)

    df.to_excel(filename, index=False)
    print(f"Excel file created: '{filename}'")

    s3_bucket = os.environ.get("Bucket")
    s3_prefix = os.environ.get("Bucket_prefix")
    s3_key = f"{s3_prefix}{property_name}_Audit.xlsx"

    # Upload to S3
    try:
        s3 = boto3.client('s3')
        s3.upload_file(filename, s3_bucket, s3_key)
        print(f"File uploaded to s3://{s3_bucket}/{s3_key}")
    except Exception as e:
        print(f"S3 upload failed: {e}")

    os.remove(filename)

def lambda_handler(event, context=None):
    TOKEN_CACHE.clear()

    region = os.environ.get('REGION_NAME')
    secret_name = os.environ.get('SECRET_NAME')

    if not region or not secret_name:
        LOG.error('REGION_NAME or SECRET_NAME missing from env')
        return

    secret = get_secret(secret_name, region)

    property_vendor_id = event.get('property_vendor_id')

    if not property_vendor_id:
        LOG.error('property_vendor_id not provided')
        return

    amenitySSID, property_name = getPropertyInfo(property_vendor_id, secret)
    LOG.info('Property name: %s', property_name)

    units_list = getUnitsFromProperty(property_vendor_id, secret)
    if not isinstance(units_list, list):
        LOG.error('Invalid property vendor ID or units_list not returned')
        return

    elocToken = getElocToken(secret)
    ftnsToken = getFtsToken(secret)
    entToken = getEntToken(secret)
    xrayToken = getXrayToken(secret)
    rpilToken = getRpilToken(secret)
    odpToken = getodpToken(secret)

    LOG.info('Starting async processing for %d units', len(units_list))

    unit_list = asyncio.run(process_units_async(units_list, elocToken, ftnsToken, secret))
    ent_list = asyncio.run(process_result_async(unit_list, entToken, secret))
    xray_list = asyncio.run(process_xray_async(ent_list, xrayToken, rpilToken, amenitySSID, units_list, odpToken, secret))

    final_list = []
    for data in xray_list:
        temp = {k: data.get(k) for k in [
            'Unit Name', 'House Key', 'Location ID', 'Address Line 1', 'Drop Cell', 'MASA',
            'CxB Badge on Servicability Page', 'XC2 Enabled', 'XC2 Resident Name', 'E360 Customer Name',
            'Name Match?', 'E360 Account Number', 'XC2 Account Number', 'Match?', 'CxB Badge on Customer in E360',
            'CxB Rate Codes', 'OnRamp Device', 'OnRamp Device Online', 'Device X1 Status (xRay)',
            'OnRamp Device Assigned to Customer', 'Active Devices Connected', 'Surfable Bootfile',
            'In-unit Network Enabled', 'In-unit Network Personalized', 'Amenity Networks Enabled', 'Guest Network Enabled'
        ]}
        final_list.append(temp)

    save_to_csv(final_list, property_name)

# if __name__ == '__main__':
#     lambda_handler({'property_vendor_id': os.getenv('PROPERTY_VENDOR_ID') or 'P-c7c0792d30e54df4849d0ecd87138ce1'}, None)