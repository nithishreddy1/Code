package com.comcast.model;

public class PropertyInfo {
    private String amenitySSID;
    private String name;
    
    public PropertyInfo(String amenitySSID, String name) {
        this.amenitySSID = amenitySSID;
        this.name = name;
    }
    
    public String getAmenitySSID() {
        return amenitySSID;
    }
    
    public String getName() {
        return name;
    }
}