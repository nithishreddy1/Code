package com.comcast;

import com.comcast.service.*;
import com.comcast.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

@Component
public class HelloWorldFunction implements Function<Map<String, Object>, ApiResponse> {

    @Autowired
    private SecretService secretService;
    
    @Autowired
    private TokenService tokenService;
    
    @Autowired
    private PropertyService propertyService;
    
    @Autowired
    private DataProcessingService dataProcessingService;
    
    @Autowired
    private JsonService jsonService;

    @Override
    public ApiResponse apply(Map<String, Object> event) {
        try {
            TokenService.clearCache();

            String region = System.getenv("REGION_NAME");
            String secretName = System.getenv("SECRET_NAME");

            if (region == null || secretName == null) {
                return ApiResponse.error("Missing environment variables");
            }

            Map<String, Object> secret = secretService.getSecret(secretName, region);
            String propertyVendorId = (String) event.get("property_vendor_id");

            if (propertyVendorId == null) {
                return ApiResponse.error("property_vendor_id not provided");
            }

            PropertyInfo propertyInfo = propertyService.getPropertyInfo(propertyVendorId, secret);

            List<Map<String, Object>> unitsList = propertyService.getUnitsFromProperty(propertyVendorId, secret);
            if (unitsList == null || unitsList.isEmpty()) {
                return ApiResponse.error("No units found");
            }

            // Get all tokens
            String elocToken = tokenService.getElocToken(secret);
            String ftnsToken = tokenService.getFtsToken(secret);
            String entToken = tokenService.getEntToken(secret);
            String xrayToken = tokenService.getXrayToken(secret);
            String rpilToken = tokenService.getRpilToken(secret);
            String odpToken = tokenService.getOdpToken(secret);



            // Process data asynchronously
            CompletableFuture<List<Map<String, Object>>> unitsFuture = dataProcessingService
                    .processUnitsAsync(unitsList, elocToken, ftnsToken, secret);

            List<Map<String, Object>> processedUnits = unitsFuture.get();

            CompletableFuture<List<Map<String, Object>>> entFuture = dataProcessingService
                    .processResultAsync(processedUnits, entToken, secret);

            List<Map<String, Object>> entProcessed = entFuture.get();

            CompletableFuture<List<Map<String, Object>>> xrayFuture = dataProcessingService.processXrayAsync(
                    entProcessed, xrayToken, rpilToken,
                    propertyInfo.getAmenitySSID(), unitsList, odpToken, secret);

            List<Map<String, Object>> finalList = xrayFuture.get();

            jsonService.saveToJson(finalList, propertyInfo.getName());

            return ApiResponse.success("Processing completed successfully", finalList, propertyInfo.getName());

        } catch (Exception e) {
            return ApiResponse.error(e.getMessage());
        }
    }


}
