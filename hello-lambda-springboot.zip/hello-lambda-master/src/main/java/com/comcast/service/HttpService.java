package com.comcast.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Random;
import java.util.Set;

@Service
public class HttpService {
    private static final Logger LOG = LoggerFactory.getLogger(HttpService.class);
    private static final Set<Integer> RETRYABLE_STATUS_CODES = Set.of(429, 500, 502, 503, 504);
    private static final int MAX_RETRIES = Integer.parseInt(System.getenv().getOrDefault("MAX_RETRIES", "3"));
    private static final double BACKOFF_FACTOR = Double.parseDouble(System.getenv().getOrDefault("BACKOFF_FACTOR", "1.5"));
    
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Random random = new Random();
    
    public Map<String, Object> retryPostRequest(String name, String url, Map<String, String> headers, String payload) {
        return retryPostRequest(name, url, headers, payload, 10);
    }
    
    public Map<String, Object> retryPostRequest(String name, String url, Map<String, String> headers, String payload, int timeout) {
        if (url == null || url.isBlank()) {
            LOG.error("[{}] No URL provided", name);
            return null;
        }
        
        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try (CloseableHttpClient client = HttpClients.createDefault()) {
                HttpPost post = new HttpPost(url);
                
                RequestConfig config = RequestConfig.custom()
                    .setSocketTimeout(timeout * 1000)
                    .setConnectTimeout(timeout * 1000)
                    .build();
                post.setConfig(config);
                
                if (headers != null) {
                    headers.forEach(post::setHeader);
                }
                
                if (payload != null) {
                    post.setEntity(new StringEntity(payload));
                }
                
                try (CloseableHttpResponse response = client.execute(post)) {
                    int status = response.getStatusLine().getStatusCode();
                    String responseBody = EntityUtils.toString(response.getEntity());
                    
                    if (status == 200) {
                        LOG.info("[{}] Token fetched successfully at attempt {} (HTTP {})", name, attempt, status);
                        return objectMapper.readValue(responseBody, Map.class);
                    }
                    
                    if (RETRYABLE_STATUS_CODES.contains(status)) {
                        LOG.warn("[{}] Attempt {}: HTTP {} - retrying...", name, attempt, status);
                    } else {
                        LOG.error("[{}] Non-retryable HTTP {} - body: {}", name, status, responseBody);
                        break;
                    }
                }
            } catch (Exception e) {
                LOG.warn("[{}] Attempt {}: Exception: {}", name, attempt, e.getMessage());
            }
            
            if (attempt < MAX_RETRIES) {
                try {
                    Thread.sleep((long) (jitteredBackoff(attempt) * 1000));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        
        LOG.error("[{}] All {} retries failed.", name, MAX_RETRIES);
        return null;
    }
    
    public Map<String, Object> retryGetRequest(String name, String url, Map<String, String> headers, int timeout) {
        if (url == null || url.isBlank()) {
            LOG.error("[{}] No URL provided", name);
            return null;
        }
        
        for (int attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try (CloseableHttpClient client = HttpClients.createDefault()) {
                HttpGet get = new HttpGet(url);
                
                RequestConfig config = RequestConfig.custom()
                    .setSocketTimeout(timeout * 1000)
                    .setConnectTimeout(timeout * 1000)
                    .build();
                get.setConfig(config);
                
                if (headers != null) {
                    headers.forEach(get::setHeader);
                }
                
                try (CloseableHttpResponse response = client.execute(get)) {
                    int status = response.getStatusLine().getStatusCode();
                    String responseBody = EntityUtils.toString(response.getEntity());
                    
                    if (status == 200) {
                        return objectMapper.readValue(responseBody, Map.class);
                    }
                    
                    if (RETRYABLE_STATUS_CODES.contains(status)) {
                        LOG.warn("[{}] Attempt {}: HTTP {} - retrying...", name, attempt, status);
                    } else {
                        LOG.error("[{}] Non-retryable HTTP {} - body: {}", name, status, responseBody);
                        break;
                    }
                }
            } catch (Exception e) {
                LOG.warn("[{}] Attempt {}: Exception: {}", name, attempt, e.getMessage());
            }
            
            if (attempt < MAX_RETRIES) {
                try {
                    Thread.sleep((long) (jitteredBackoff(attempt) * 1000));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        
        LOG.error("[{}] All {} retries failed.", name, MAX_RETRIES);
        return null;
    }
    
    private double jitteredBackoff(int attempt) {
        double base = Math.pow(BACKOFF_FACTOR, attempt);
        return base + random.nextDouble() * base;
    }
}