package com.comcast.service;

import com.comcast.model.PropertyInfo;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PropertyService {
    private static final Logger LOG = LoggerFactory.getLogger(PropertyService.class);
    
    @Autowired
    private SecretService secretService;
    
    @Autowired
    private TokenService tokenService;
    
    @Autowired
    private HttpService httpService;
    
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    public PropertyInfo getPropertyInfo(String propertyVendorId, Map<String, Object> secret) {
        String url = secretService.sget(secret, "xc2-identity") + "/" + propertyVendorId;
        Map<String, String> headers = Map.of("Authorization", "Bearer " + tokenService.getProdToken(secret));
        
        try {
            Map<String, Object> response = httpService.retryGetRequest("PropertyInfo", url, headers, 10);
            if (response != null) {
                String name = (String) response.get("name");
                String ssidValue = null;
                
                List<Map<String, Object>> extendedProperties = (List<Map<String, Object>>) response.get("extended_properties");
                if (extendedProperties != null) {
                    for (Map<String, Object> prop : extendedProperties) {
                        if ("AMENITYNETWORK_DEFAULTSSID".equals(prop.get("identifier_type"))) {
                            ssidValue = (String) prop.get("value");
                            break;
                        }
                    }
                }
                
                return new PropertyInfo(ssidValue, name);
            }
        } catch (Exception e) {
            LOG.error("getPropertyInfo failed", e);
        }
        
        return new PropertyInfo(null, null);
    }
    
    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> getUnitsFromProperty(String propertyVendorId, Map<String, Object> secret) {
        String url = secretService.sget(secret, "xc2-pms-units") + "/" + propertyVendorId + "/units";
        Map<String, String> headers = Map.of("Authorization", "Bearer " + tokenService.getProdToken(secret));
        
        try {
            Map<String, Object> response = httpService.retryGetRequest("UnitsFromProperty", url, headers, 10);
            if (response != null) {
                return (List<Map<String, Object>>) response.get("units");
            }
        } catch (Exception e) {
            LOG.error("getUnitsFromProperty failed", e);
        }
        
        return null;
    }
}