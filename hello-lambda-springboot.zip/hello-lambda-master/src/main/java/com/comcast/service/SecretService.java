package com.comcast.service;

import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.model.GetSecretValueRequest;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class SecretService {
    private static final Logger LOG = LoggerFactory.getLogger(SecretService.class);
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    @Autowired
    private AWSSecretsManager secretsManager;
    
    public Map<String, Object> getSecret(String secretName, String region) {
        try {
            GetSecretValueRequest request = new GetSecretValueRequest()
                .withSecretId(secretName);
                
            GetSecretValueResult result = secretsManager.getSecretValue(request);
            
            String secretString = result.getSecretString();
            if (secretString != null) {
                return objectMapper.readValue(secretString, Map.class);
            } else {
                return objectMapper.readValue(result.getSecretBinary().array(), Map.class);
            }
        } catch (Exception e) {
            LOG.error("Failed to get secret", e);
            throw new RuntimeException("Failed to get secret", e);
        }
    }
    
    public String sget(Map<String, Object> secret, String key) {
        return sget(secret, key, null);
    }
    
    public String sget(Map<String, Object> secret, String key, String defaultValue) {
        if (secret == null) return defaultValue;
        Object value = secret.get(key);
        return value != null ? value.toString() : defaultValue;
    }
}